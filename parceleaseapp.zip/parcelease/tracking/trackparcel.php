<?php
header("Content-Type: application/json; charset=UTF-8");
include "../dbconnect.php"; // Ensure database connection

if ($_SERVER["REQUEST_METHOD"] !== "POST") {
    echo json_encode(["status" => "error", "message" => "Invalid request method"]);
    exit;
}

$parcel_id = $_POST['parcel_id'] ?? null;

if (!$parcel_id) {
    echo json_encode(["status" => "error", "message" => "Parcel ID is required"]);
    exit;
}

// Query to fetch tracking details
$trackingQuery = "SELECT status, current_location, previous_locations, eta FROM tracking WHERE parcel_id = ?";
$stmtTracking = $conn->prepare($trackingQuery);
$stmtTracking->bind_param("s", $parcel_id);
$stmtTracking->execute();
$resultTracking = $stmtTracking->get_result();

if ($resultTracking->num_rows == 0) {
    echo json_encode(["status" => "error", "message" => "Tracking details not found"]);
    exit;
}

$trackingData = $resultTracking->fetch_assoc();
$stmtTracking->close();

// Convert previous locations to JSON array
$previousLocations = explode(",", $trackingData['previous_locations']);
$trackingData['previous_locations'] = [];

foreach ($previousLocations as $location) {
    $coords = explode(" ", trim($location)); // Split lat,lng
    if (count($coords) == 2) {
        $trackingData['previous_locations'][] = [
            "latitude" => floatval($coords[0]),
            "longitude" => floatval($coords[1])
        ];
    }
}

// Query to fetch parcel details
$parcelQuery = "SELECT parcel_id, user_id, pickup_location, drop_location, weight, status, created_at FROM parcels WHERE parcel_id = ?";
$stmtParcel = $conn->prepare($parcelQuery);
$stmtParcel->bind_param("s", $parcel_id);
$stmtParcel->execute();
$resultParcel = $stmtParcel->get_result();

if ($resultParcel->num_rows == 0) {
    echo json_encode(["status" => "error", "message" => "Parcel details not found"]);
    exit;
}

$parcelData = $resultParcel->fetch_assoc();
$stmtParcel->close();

// Merge both data
$response = [
    "status" => "success",
    "tracking_details" => $trackingData,
    "parcel_details" => $parcelData
];

error_log("Response: " . json_encode($response)); // Debugging log
echo json_encode($response, JSON_PRETTY_PRINT);
$conn->close();
?>
