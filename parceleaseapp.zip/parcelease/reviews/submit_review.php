<?php
header("Content-Type: application/json");
session_start();
include "../dbconnect.php";

// Check if user is logged in
if (!isset($_SESSION['user_id'])) {
    echo json_encode(["status" => "error", "message" => "User not logged in"]);
    exit;
}

$user_id = $_SESSION['user_id']; // Logged-in user ID

// Check if request is POST
if ($_SERVER["REQUEST_METHOD"] !== "POST") {
    echo json_encode(["status" => "error", "message" => "Invalid request method"]);
    exit;
}

// Validate input
if (!isset($_POST['parcel_id'], $_POST['driver_id'], $_POST['rating'], $_POST['comments'])) {
    echo json_encode(["status" => "error", "message" => "Missing required fields"]);
    exit;
}

$parcel_id = $_POST['parcel_id'];
$driver_id = $_POST['driver_id'];
$rating = intval($_POST['rating']);
$comments = trim($_POST['comments']);

// Ensure rating is between 1 and 5
if ($rating < 1 || $rating > 5) {
    echo json_encode(["status" => "error", "message" => "Rating must be between 1 and 5"]);
    exit;
}

// Check if the user is the owner of the parcel
$check_query = "SELECT parcel_id FROM parcels WHERE parcel_id = ? AND user_id = ?";
$stmt_check = $conn->prepare($check_query);
$stmt_check->bind_param("si", $parcel_id, $user_id);
$stmt_check->execute();
$stmt_check->store_result();

if ($stmt_check->num_rows == 0) {
    echo json_encode(["status" => "error", "message" => "You are not authorized to review this parcel"]);
    exit;
}
$stmt_check->close();

// Insert review
$query = "INSERT INTO reviews (parcel_id, user_id, driver_id, rating, comments) VALUES (?, ?, ?, ?, ?)";
$stmt = $conn->prepare($query);
$stmt->bind_param("siiss", $parcel_id, $user_id, $driver_id, $rating, $comments);

if ($stmt->execute()) {
    echo json_encode(["status" => "success", "message" => "Review submitted successfully"]);
} else {
    echo json_encode(["status" => "error", "message" => "Failed to submit review"]);
}

$stmt->close();
$conn->close();
?>
