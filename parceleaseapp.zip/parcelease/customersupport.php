<?php
include "../dbconnect.php";

$data = json_decode(file_get_contents("php://input"));

$user_id = $data->user_id;
$category = $data->issue_category;
$description = $data->description;

$query = "INSERT INTO support_tickets (user_id, issue_category, description) VALUES (?, ?, ?)";
$stmt = $conn->prepare($query);
$stmt->bind_param("iss", $user_id, $category, $description);

if ($stmt->execute()) {
    echo json_encode(["message" => "Support ticket created"]);
} else {
    echo json_encode(["error" => "Ticket creation failed"]);
}
?>
