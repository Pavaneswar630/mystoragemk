<?php
include "../dbconnect.php"; // Database connection

header("Content-Type: application/json");
header("Access-Control-Allow-Origin: *");
header("Access-Control-Allow-Methods: POST");
header("Access-Control-Allow-Headers: Content-Type, Access-Control-Allow-Headers, Authorization, X-Requested-With");

// Accept form-data input
if (!isset($_POST['user_id'], $_POST['parcel_id'], $_POST['amount'], $_POST['payment_method'], $_POST['payment_status'], $_POST['transaction_id'])) {
    echo json_encode(["error" => "Missing required fields"]);
    exit;
}

$user_id = $_POST['user_id'];
$parcel_id = $_POST['parcel_id'];
$amount = $_POST['amount'];
$payment_method = $_POST['payment_method'];
$status = $_POST['payment_status'];
$transaction_id = $_POST['transaction_id'];

// Insert payment record
$query = "INSERT INTO payments (user_id, parcel_id, amount, payment_method, payment_status, transaction_id) 
          VALUES (?, ?, ?, ?, ?, ?)";

$stmt = $conn->prepare($query);
$stmt->bind_param("isdsss", $user_id, $parcel_id, $amount, $payment_method, $status, $transaction_id);

if ($stmt->execute()) {
    echo json_encode([
        "success" => "Payment record created",
        "payment_id" => $stmt->insert_id,
        "transaction_id" => $transaction_id
    ]);
} else {
    echo json_encode(["error" => "Payment failed", "details" => $stmt->error]);
}

$stmt->close();
$conn->close();
?>
