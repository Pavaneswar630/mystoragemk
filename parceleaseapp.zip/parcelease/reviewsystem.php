<?php
include "../dbconnect.php";

$data = json_decode(file_get_contents("php://input"));

$user_id = $data->user_id;
$parcel_id = $data->parcel_id;
$rating = $data->rating;
$review = $data->review;

$query = "INSERT INTO reviews (user_id, parcel_id, rating, review) VALUES (?, ?, ?, ?)";
$stmt = $conn->prepare($query);
$stmt->bind_param("iiis", $user_id, $parcel_id, $rating, $review);

if ($stmt->execute()) {
    echo json_encode(["message" => "Review submitted"]);
} else {
    echo json_encode(["error" => "Review submission failed"]);
}
?>
