<?php
header("Content-Type: application/json");
include "../dbconnect.php";
session_start();

// Check if user is logged in
if (!isset($_SESSION['user_id'])) {
    echo json_encode(["status" => "error", "message" => "User not logged in"]);
    exit;
}

$user_id = $_SESSION['user_id'];

// Validate request method
if ($_SERVER["REQUEST_METHOD"] !== "POST") {
    echo json_encode(["status" => "error", "message" => "Invalid request method"]);
    exit;
}

// Get request data
$subject = $_POST['subject'] ?? '';
$message = $_POST['message'] ?? '';

// Validate input
if (empty($subject) || empty($message)) {
    echo json_encode(["status" => "error", "message" => "Subject and message are required"]);
    exit;
}

// Insert into support_requests table
$query = "INSERT INTO support_requests (user_id, subject, message, status) VALUES (?, ?, ?, 'Pending')";
$stmt = $conn->prepare($query);
$stmt->bind_param("iss", $user_id, $subject, $message);

if ($stmt->execute()) {
    echo json_encode(["status" => "success", "message" => "Support request submitted successfully"]);
} else {
    echo json_encode(["status" => "error", "message" => "Failed to submit support request"]);
}

$stmt->close();
$conn->close();
?>
