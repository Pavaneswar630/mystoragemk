<?php
session_start();
include "../dbconnect.php";
header("Content-Type: application/json");

// Allow only POST method
if ($_SERVER["REQUEST_METHOD"] !== "POST") {
    echo json_encode(["status" => "error", "message" => "Invalid request method"]);
    exit;
}

// Check if user is logged in
if (!isset($_SESSION['user_id'])) {
    echo json_encode(["status" => "error", "message" => "User not authenticated"]);
    exit;
}

$user_id = $_SESSION['user_id'];

// Prepare query to get recent tickets
$sql = "SELECT id, subject, status, created_at FROM support_requests WHERE user_id = ? ORDER BY created_at DESC";
$stmt = $conn->prepare($sql);
$stmt->bind_param("i", $user_id);
$stmt->execute();
$result = $stmt->get_result();

$tickets = [];

while ($row = $result->fetch_assoc()) {
    $tickets[] = [
        "id" => $row["id"],
        "subject" => $row["subject"],
        "status" => $row["status"],
        "created_at" => $row["created_at"]
    ];
}

echo json_encode($tickets);

$stmt->close();
$conn->close();
?>
