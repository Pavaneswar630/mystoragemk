<?php
header("Content-Type: application/json");
include "../dbconnect.php"; // Database connection

if ($_SERVER["REQUEST_METHOD"] !== "POST") {
    echo json_encode(["status" => "error", "message" => "Invalid request method"]);
    exit;
}

// Get the question from form data
$question = $_POST['question'] ?? '';

if (empty($question)) {
    echo json_encode(["status" => "error", "message" => "Question is required"]);
    exit;
}

// Search for a matching FAQ
$query = "SELECT answer FROM faqs WHERE question LIKE ? LIMIT 1";
$stmt = $conn->prepare($query);
$searchQuery = "%$question%"; // Allow partial matches
$stmt->bind_param("s", $searchQuery);
$stmt->execute();
$result = $stmt->get_result();

if ($result->num_rows > 0) {
    $row = $result->fetch_assoc();
    echo json_encode(["status" => "success", "answer" => $row['answer']]);
} else {
    echo json_encode(["status" => "error", "message" => "No matching answer found"]);
}

$stmt->close();
$conn->close();
?>
