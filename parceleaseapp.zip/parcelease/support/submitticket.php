<?php
header('Content-Type: application/json');
include '../dbconnect.php';

$response = [];

$user_id = $_POST['user_id'] ?? '';
$title = $_POST['title'] ?? '';
$message = $_POST['message'] ?? '';

if (empty($user_id) || empty($title) || empty($message)) {
    $response['status'] = 'error';
    $response['message'] = 'User ID, title, and message are required';
    echo json_encode($response);
    exit;
}

$stmt = $conn->prepare("INSERT INTO support_requests (user_id, subject, message, status, created_at) VALUES (?, ?, ?, 'pending', NOW())");
$stmt->bind_param("iss", $user_id, $title, $message);

if ($stmt->execute()) {
    $response['status'] = 'success';
    $response['message'] = 'Ticket submitted successfully';
} else {
    $response['status'] = 'error';
    $response['message'] = 'Failed to submit ticket';
}

$stmt->close();
$conn->close();

echo json_encode($response);
?>
