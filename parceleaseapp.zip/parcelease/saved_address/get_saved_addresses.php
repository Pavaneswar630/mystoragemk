<?php
header('Content-Type: application/json');

// Include your existing DB connection
require_once '../dbconnect.php'; // adjust path as needed

// Check for POST and user_id parameter
if ($_SERVER['REQUEST_METHOD'] !== 'POST') {
    http_response_code(405);
    echo json_encode(["status" => "error", "message" => "Only POST requests are allowed"]);
    exit();
}

$user_id = isset($_POST['user_id']) ? $conn->real_escape_string($_POST['user_id']) : '';

if (empty($user_id)) {
    echo json_encode(["status" => "error", "message" => "Missing user_id"]);
    exit();
}

// Prepare and execute query
$sql = "SELECT name, phone, location, remarks FROM saved_addresses WHERE user_id = '$user_id'";
$result = $conn->query($sql);

if (!$result) {
    echo json_encode(["status" => "error", "message" => "Database error: " . $conn->error]);
    exit();
}

$addresses = [];

while ($row = $result->fetch_assoc()) {
    $addresses[] = $row;
}

echo json_encode(["status" => "success", "addresses" => $addresses]);

$conn->close();
?>
