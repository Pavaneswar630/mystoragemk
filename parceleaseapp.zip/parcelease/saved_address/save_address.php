<?php
header('Content-Type: application/json');

// Include the existing connection
require_once '../dbconnect.php'; // Adjust path if needed

// Get POST data safely
$user_id = isset($_POST['user_id']) ? $conn->real_escape_string($_POST['user_id']) : '';
$name = isset($_POST['name']) ? $conn->real_escape_string($_POST['name']) : '';
$phone = isset($_POST['phone']) ? $conn->real_escape_string($_POST['phone']) : '';
$location = isset($_POST['location']) ? $conn->real_escape_string($_POST['location']) : '';
$remarks = isset($_POST['remarks']) ? $conn->real_escape_string($_POST['remarks']) : '';

// Validate required fields
if (empty($user_id) || empty($name) || empty($phone) || empty($location)) {
    echo json_encode(["status" => "error", "message" => "Required fields missing"]);
    exit;
}

// Prepare SQL statement
$sql = "INSERT INTO saved_addresses (user_id, name, phone, location, remarks)
        VALUES ('$user_id', '$name', '$phone', '$location', '$remarks')
        ON DUPLICATE KEY UPDATE
            name='$name',
            phone='$phone',
            location='$location',
            remarks='$remarks'";

if ($conn->query($sql) === TRUE) {
    echo json_encode(["status" => "success", "message" => "Address saved successfully."]);
} else {
    echo json_encode(["status" => "error", "message" => "Error: " . $conn->error]);
}

$conn->close();
