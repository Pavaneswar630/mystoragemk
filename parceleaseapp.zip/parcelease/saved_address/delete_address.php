<?php
session_start(); // Start session
header("Content-Type: application/json");
include "../dbconnect.php"; // Include database connection

// Enable error reporting (for debugging)
error_reporting(E_ALL);
ini_set('display_errors', 1);

// Check if user is logged in
if (!isset($_SESSION['user_id'])) {
    echo json_encode(["status" => "error", "message" => "User not logged in"]);
    exit;
}

$user_id = $_SESSION['user_id']; // Logged-in user's ID

// Check if the request is POST
if ($_SERVER["REQUEST_METHOD"] !== "POST") {
    echo json_encode(["status" => "error", "message" => "Invalid request method"]);
    exit;
}

// Check if the address ID is provided
if (!isset($_POST['address_id'])) {
    echo json_encode(["status" => "error", "message" => "Missing address ID"]);
    exit;
}

$address_id = $_POST['address_id'];

// Verify that the address exists and belongs to the user
$checkQuery = "SELECT id FROM saved_addresses WHERE id = ? AND user_id = ?";
$stmtCheck = $conn->prepare($checkQuery);
$stmtCheck->bind_param("ii", $address_id, $user_id);
$stmtCheck->execute();
$stmtCheck->store_result();

if ($stmtCheck->num_rows == 0) {
    echo json_encode(["status" => "error", "message" => "Address not found or does not belong to the user"]);
    exit;
}

// Delete the address
$deleteQuery = "DELETE FROM saved_addresses WHERE id = ? AND user_id = ?";
$stmtDelete = $conn->prepare($deleteQuery);
$stmtDelete->bind_param("ii", $address_id, $user_id);

if ($stmtDelete->execute()) {
    echo json_encode(["status" => "success", "message" => "Address deleted successfully"]);
} else {
    echo json_encode(["status" => "error", "message" => "Failed to delete address"]);
}

// Close connections
$stmtCheck->close();
$stmtDelete->close();
$conn->close();
?>
