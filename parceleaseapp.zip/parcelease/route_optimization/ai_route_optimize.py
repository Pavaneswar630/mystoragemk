import sys
import json

def assign_truck_and_route(parcels, trucks, branches):
    """Assigns trucks and determines optimal routes for parcels."""
    
    optimized_routes = []

    for parcel in parcels:
        try:
            # Convert pickup/drop locations from strings to lat/lng
            pickup_lat, pickup_lng = map(float, parcel["pickup_location"].split(", "))
            drop_lat, drop_lng = map(float, parcel["drop_location"].split(", "))
            parcel["pickup_lat"] = pickup_lat
            parcel["pickup_lng"] = pickup_lng
            parcel["drop_lat"] = drop_lat
            parcel["drop_lng"] = drop_lng
            parcel["weight"] = float(parcel["weight"])

            # Select the best truck based on minimum excess capacity
            truck = min(trucks, key=lambda t: abs(float(t["capacity"]) - parcel["weight"]))

            # Find the closest branch (if applicable)
            closest_branch = min(branches, key=lambda b: (
                abs(float(b["latitude"]) - pickup_lat) + abs(float(b["longitude"]) - pickup_lng)
            ))

            # Store optimized route
            optimized_routes.append({
                "parcel_id": parcel["parcel_id"],
                "truck_id": truck["id"],
                "pickup_lat": pickup_lat,
                "pickup_lng": pickup_lng,
                "drop_lat": drop_lat,
                "drop_lng": drop_lng,
                "assigned_branch": closest_branch["branch_id"]
            })

        except Exception as e:
            return {"status": "error", "message": f"Error processing parcel {parcel['parcel_id']}: {str(e)}"}

    return {"status": "success", "routes": optimized_routes}

# ✅ Read JSON input from PHP
input_data = json.load(sys.stdin)

# ✅ Process route optimization
result = assign_truck_and_route(input_data["parcels"], input_data["trucks"], input_data["branches"])

# ✅ Output the result in JSON format for PHP to capture
print(json.dumps(result))
