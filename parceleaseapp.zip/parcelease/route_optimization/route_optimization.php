<?php
include '../dbconnect.php';

header('Content-Type: application/json');

// ✅ Fetch data from database
$parcels_query = "SELECT * FROM parcels WHERE status = 'Confirmed'";
$trucks_query = "SELECT * FROM trucks WHERE availability = 'Available'";
$branches_query = "SELECT * FROM branches";

$parcels = $conn->query($parcels_query)->fetch_all(MYSQLI_ASSOC);
$trucks = $conn->query($trucks_query)->fetch_all(MYSQLI_ASSOC);
$branches = $conn->query($branches_query)->fetch_all(MYSQLI_ASSOC);

// ✅ Prepare JSON payload for Python
$request_data = json_encode([
    "parcels" => $parcels,
    "trucks" => $trucks,
    "branches" => $branches
]);

// ✅ Call Python script
$python_path = "C:/Users/dhana/AppData/Local/Programs/Python/Python313/python.exe";
$script_path = "c:/xampp/htdocs/parcelease/route_optimization/ai_route_optimize.py";

$command = "echo " . escapeshellarg($request_data) . " | $python_path $script_path";
$output = shell_exec($command);

// ✅ Decode response
$response = json_decode($output, true);

if ($response["status"] === "success") {
    // ✅ Insert optimized routes into database
    foreach ($response["routes"] as $route) {
        $stmt = $conn->prepare("INSERT INTO optimized_routes (parcel_id, truck_id, pickup_lat, pickup_lng, drop_lat, drop_lng, assigned_branch) VALUES (?, ?, ?, ?, ?, ?, ?)");
        $stmt->bind_param("siddddi", $route["parcel_id"], $route["truck_id"], $route["pickup_lat"], $route["pickup_lng"], $route["drop_lat"], $route["drop_lng"], $route["assigned_branch"]);
        $stmt->execute();
    }

    echo json_encode(["status" => "success", "message" => "Routes optimized successfully"]);
} else {
    echo json_encode(["status" => "error", "message" => $response["message"]]);
}

$conn->close();
?>
