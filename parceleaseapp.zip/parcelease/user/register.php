<?php
require '../dbconnect.php'; // Include database connection

header('Content-Type: application/json');

if ($_SERVER["REQUEST_METHOD"] == "POST") {
    $name = $_POST['name'] ?? '';
    $email = $_POST['email'] ?? '';
    $password = $_POST['password'] ?? '';
    $phone = $_POST['phone'] ?? '';

    // Validate required fields
    if (empty($name) || empty($email) || empty($password) || empty($phone)) {
        echo json_encode(["status" => "error", "message" => "All fields are required"]);
        exit();
    }

    // Check if email exists
    $check_query = $conn->prepare("SELECT id FROM users WHERE email = ?");
    $check_query->bind_param("s", $email);
    $check_query->execute();
    $result = $check_query->get_result();

    if ($result->num_rows > 0) {
        echo json_encode(["status" => "error", "message" => "Email already exists!"]);
        exit();
    }

    // **Default profile picture (BLOB)**
    $default_image_path = "../uploads/default.png";
    $profile_pic_blob = file_get_contents($default_image_path); // Read default image as BLOB

    // **Check if user uploaded a new image**
    if (!empty($_FILES['profile_image']['tmp_name'])) {
        $profile_pic_blob = file_get_contents($_FILES['profile_image']['tmp_name']); // Use uploaded image
    }

    // **Insert user into database**
    $stmt = $conn->prepare("INSERT INTO users (name, email, password, phone, profile_pic) VALUES (?, ?, ?, ?, ?)");
    $stmt->bind_param("sssss", $name, $email, $password, $phone, $null);

    // **Bind BLOB Data**
    $stmt->send_long_data(4, $profile_pic_blob);

    if ($stmt->execute()) {
        echo json_encode(["status" => "success", "message" => "User registered successfully."]);
    } else {
        echo json_encode(["status" => "error", "message" => "Registration failed!"]);
    }

    $stmt->close();
    $conn->close();
}
?>
