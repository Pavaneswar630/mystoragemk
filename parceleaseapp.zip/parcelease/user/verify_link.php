<?php
use PHPMailer\PHPMailer\PHPMailer;
use PHPMailer\PHPMailer\Exception;

require '../PHPMailer/src/PHPMailer.php';
require '../PHPMailer/src/SMTP.php';
require '../PHPMailer/src/Exception.php';

include "../dbconnect.php"; // Database connection

header("Content-Type: application/json");

if ($_SERVER["REQUEST_METHOD"] == "POST") {
    $email = $_POST['email'] ?? '';

    if (empty($email)) {
        echo json_encode(["status" => "error", "message" => "Email is required"]);
        exit;
    }

    // Check if the email exists
    $check_query = "SELECT id FROM users WHERE email = ?";
    $stmt = $conn->prepare($check_query);
    $stmt->bind_param("s", $email);
    $stmt->execute();
    $stmt->store_result();

    if ($stmt->num_rows == 0) {
        echo json_encode(["status" => "error", "message" => "Email not found"]);
        exit;
    }

    // Generate OTP and expiry time (valid for 10 minutes)
    $otp = rand(100000, 999999);
    $otp_expiry = date("Y-m-d H:i:s", strtotime("+10 minutes"));

    // Store OTP in database
    $update_query = "UPDATE users SET otp = ?, otp_expiry = ? WHERE email = ?";
    $stmt = $conn->prepare($update_query);
    $stmt->bind_param("sss", $otp, $otp_expiry, $email);

    if ($stmt->execute()) {
        // Send email using PHPMailer
        $mail = new PHPMailer(true);

        try {
            $mail->isSMTP();
            $mail->Host = 'smtp.gmail.com';
            $mail->SMTPAuth = true;
            $mail->Username = 'pavaneswar224@gmail.com'; 
            $mail->Password = 'azmc qwff lwxe pnvu'; // App Password
            $mail->SMTPSecure = PHPMailer::ENCRYPTION_STARTTLS;
            $mail->Port = 587;

            $mail->setFrom('pavaneswar224@gmail.com', 'ParcelEase Support');
            $mail->addAddress($email);
            $mail->Subject = 'Email Verification OTP';
            $mail->isHTML(true);
            $mail->Body = "Your OTP for email verification is: <b>$otp</b>. This OTP expires in 10 minutes.";

            if ($mail->send()) {
                echo json_encode(["status" => "success", "message" => "OTP sent to your email"]);
            } else {
                echo json_encode(["status" => "error", "message" => "Failed to send OTP email"]);
            }
        } catch (Exception $e) {
            echo json_encode(["status" => "error", "message" => "Mailer Error: " . $mail->ErrorInfo]);
        }
    } else {
        echo json_encode(["status" => "error", "message" => "Failed to generate OTP"]);
    }

    $stmt->close();
    $conn->close();
} else {
    echo json_encode(["status" => "error", "message" => "Invalid request method"]);
}
?>
