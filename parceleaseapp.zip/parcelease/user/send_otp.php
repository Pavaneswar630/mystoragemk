<?php
// send_otp.php

use PHPMailer\PHPMailer\PHPMailer;
use PHPMailer\PHPMailer\Exception;

// Include PHPMailer using Composer
require '../PHPMailer/src/PHPMailer.php';
require '../PHPMailer/src/SMTP.php';
require '../PHPMailer/src/Exception.php';

// Include Database Connection
require '../dbconnect.php';

header('Content-Type: application/json');

// Get email and OTP from POST
$email = isset($_POST['email']) ? $_POST['email'] : '';
$otp = isset($_POST['otp']) ? $_POST['otp'] : '';

if (empty($email) || empty($otp)) {
    echo json_encode(['status' => 'error', 'message' => 'Email and OTP are required']);
    exit;
}

// Initialize PHPMailer
$mail = new PHPMailer(true);

try {
    // SMTP settings
    $mail->isSMTP();
    $mail->Host = 'smtp.gmail.com';
    $mail->SMTPAuth = true;
    $mail->Username = 'pavaneswar224@gmail.com';    // Your Gmail
    $mail->Password = 'azmc qwff lwxe pnvu';         // App Password
    $mail->SMTPSecure = PHPMailer::ENCRYPTION_STARTTLS;
    $mail->Port = 587;

    // Email setup
    $mail->setFrom('pavaneswar224@gmail.com', 'ParcelEase Support');
    $mail->addAddress($email);

    $mail->isHTML(true);
    $mail->Subject = 'Your OTP for Account Verification';
    $mail->Body    = "
        <h2>Hello!</h2>
        <p>Your OTP for verifying your account is: <strong style='font-size:18px;'>$otp</strong></p>
        <p>Please do not share this code with anyone.</p>
        <br>
        <p>Thank you,<br>ParcelEase Team</p>
    ";

    $mail->send();

    echo json_encode(['status' => 'success', 'message' => 'OTP sent successfully']);

} catch (Exception $e) {
    echo json_encode(['status' => 'error', 'message' => 'Mailer Error: ' . $mail->ErrorInfo]);
}

// Close the DB connection
$conn->close();
?>
