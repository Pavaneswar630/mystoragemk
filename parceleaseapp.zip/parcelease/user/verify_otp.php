<?php
include "../dbconnect.php"; // Database connection

header("Content-Type: application/json");

if ($_SERVER["REQUEST_METHOD"] == "POST") {
    $email = $_POST['email'] ?? '';
    $otp = $_POST['otp'] ?? '';

    if (empty($email) || empty($otp)) {
        echo json_encode(["status" => "error", "message" => "Email and OTP are required"]);
        exit;
    }

    // Fetch OTP details
    $stmt = $conn->prepare("SELECT otp, otp_expiry FROM users WHERE email = ?");
    $stmt->bind_param("s", $email);
    $stmt->execute();
    $result = $stmt->get_result();

    if ($result->num_rows == 0) {
        echo json_encode(["status" => "error", "message" => "Email not found"]);
        exit;
    }

    $user = $result->fetch_assoc();
    $stored_otp = $user['otp'];
    $otp_expiry = strtotime($user['otp_expiry']);
    $current_time = time();

    if ($stored_otp != $otp) {
        echo json_encode(["status" => "error", "message" => "Invalid OTP"]);
    } elseif ($current_time > $otp_expiry) {
        echo json_encode(["status" => "error", "message" => "OTP has expired"]);
    } else {
        // Update user status to "verified"
        $update_stmt = $conn->prepare("UPDATE users SET status = 'verified' WHERE email = ?");
        $update_stmt->bind_param("s", $email);

        if ($update_stmt->execute()) {
            echo json_encode(["status" => "success", "message" => "Email verified successfully"]);
        } else {
            echo json_encode(["status" => "error", "message" => "Verification failed"]);
        }
    }

    $stmt->close();
    $conn->close();
} else {
    echo json_encode(["status" => "error", "message" => "Invalid request method"]);
}
?>
