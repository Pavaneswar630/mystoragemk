<?php
include "../dbconnect.php";

// Check if token exists in the URL
if (!isset($_GET['token'])) {
    die("Invalid reset link.");
}

$token = $_GET['token'];

// Check if the token is valid in the database
$query = "SELECT id FROM users WHERE reset_token = ?";
$stmt = $conn->prepare($query);
$stmt->bind_param("s", $token);
$stmt->execute();
$result = $stmt->get_result();

if ($result->num_rows == 0) {
    die("Invalid or expired reset link.");
}

$stmt->close();
$conn->close();
?>

<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Reset Password</title>
</head>
<body>
    <h2>Reset Your Password</h2>
    <form action="resetpassword_process.php" method="POST">
        <input type="hidden" name="token" value="<?php echo htmlspecialchars($token); ?>">
        <label>New Password:</label>
        <input type="password" name="new_password" required>
        <br>
        <button type="submit">Reset Password</button>
    </form>
</body>
</html>
