<?php
include "../dbconnect.php";

if (!isset($_GET['user_id'])) {
    die("Missing user ID");
}

$user_id = $_GET['user_id'];
$sql = "SELECT profile_pic FROM users WHERE id = ?";
$stmt = $conn->prepare($sql);
$stmt->bind_param("i", $user_id);
$stmt->execute();
$stmt->store_result();
$stmt->bind_result($profile_pic);
$stmt->fetch();

if ($profile_pic) {
    header("Content-Type: image/jpeg"); // Change based on image type
    echo $profile_pic;
} else {
    echo "No image found";
}
?>
