<?php
session_start(); // Start the session
include "../dbconnect.php";
header("Content-Type: application/json");

// Check if form data is submitted
if ($_SERVER["REQUEST_METHOD"] !== "POST") {
    echo json_encode(["status" => "error", "message" => "Invalid request method"]);
    exit;
}

if (!isset($_POST['email'], $_POST['password'])) {
    echo json_encode(["status" => "error", "message" => "Missing email or password"]);
    exit;
}

$email = $_POST['email'];
$password = $_POST['password'];

// Check if user exists and is active
$sql = "SELECT id, name, password, status, profile_pic FROM users WHERE email = ?";
$stmt = $conn->prepare($sql);
$stmt->bind_param("s", $email);
$stmt->execute();                  
$result = $stmt->get_result();

if ($result->num_rows > 0) {
    $user = $result->fetch_assoc();
    
    // Check if the user is active
    if ($user['status'] !== 'active') {
        echo json_encode(["status" => "error", "message" => "Account not activated. Please verify your email."]);
        exit;
    }

    // **NO HASHING - Direct password comparison**
    if ($password === $user['password']) { 
        $_SESSION['user_id'] = $user['id']; // Store user ID in session
        $_SESSION['user_name'] = $user['name']; // Store user name
        $_SESSION['profile_pic'] = $user['profile_pic']; // Store profile pic

        echo json_encode([
            "status" => "success",
            "message" => "Login successful",
            "user_id" => $user['id'],
            "user_name" => $user['name'],
            "profile_pic" => $user['profile_pic'] // Include profile picture
        ]);
        
    } else {
        echo json_encode(["status" => "error", "message" => "Invalid password"]);
    }
} else {
    echo json_encode(["status" => "error", "message" => "User not found"]);
}

$stmt->close();
$conn->close();
?>
