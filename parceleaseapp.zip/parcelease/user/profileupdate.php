<?php
session_start();
header("Content-Type: application/json");
include "../dbconnect.php";  // Database connection

// Ensure user is logged in
if (!isset($_SESSION['user_id'])) {
    echo json_encode(["error" => "User not logged in"]);
    exit;
}

$user_id = $_SESSION['user_id'];
$name = $_POST['name'] ?? null;
$email = $_POST['email'] ?? null;
$phone = $_POST['phone'] ?? null;
$address = $_POST['address'] ?? null;

// Fetch current user details
$query = "SELECT name, email, phone, address, profile_pic FROM users WHERE id = ?";
$stmt = $conn->prepare($query);
$stmt->bind_param("i", $user_id);
$stmt->execute();
$result = $stmt->get_result();
$user = $result->fetch_assoc();

if (!$user) {
    echo json_encode(["error" => "User not found"]);
    exit;
}

// Keep existing values if new ones are not provided
$updated_name = $name ?? $user['name'];
$updated_email = $email ?? $user['email'];
$updated_phone = $phone ?? $user['phone'];
$updated_address = $address ?? $user['address'];
$profile_pic = $user['profile_pic']; // Keep existing profile pic by default

// Check if email is changed and validate uniqueness
if (!empty($email) && $email !== $user['email']) {
    $check_email_query = "SELECT id FROM users WHERE email = ? AND id != ?";
    $stmt = $conn->prepare($check_email_query);
    $stmt->bind_param("si", $email, $user_id);
    $stmt->execute();
    $stmt->store_result();

    if ($stmt->num_rows > 0) {
        echo json_encode(["error" => "Email already in use"]);
        exit;
    }
}

// Handle Profile Picture Upload (Optional)
if (isset($_FILES['profile_pic']) && $_FILES['profile_pic']['error'] == 0) {
    $target_dir = "uploads/"; // Folder to store images
    $file_name = time() . "_" . basename($_FILES["profile_pic"]["name"]); // Unique filename
    $target_file = $target_dir . $file_name;

    if (move_uploaded_file($_FILES["profile_pic"]["tmp_name"], $target_file)) {
        // Delete old profile picture (if not default)
        if ($profile_pic !== "uploads/default.jpg" && file_exists($profile_pic)) {
            unlink($profile_pic);
        }
        $profile_pic = $target_file;
    }
}

// Update user details in the database
$update_query = "UPDATE users SET name = ?, email = ?, phone = ?, address = ?, profile_pic = ? WHERE id = ?";
$stmt = $conn->prepare($update_query);
$stmt->bind_param("sssssi", $updated_name, $updated_email, $updated_phone, $updated_address, $profile_pic, $user_id);

if ($stmt->execute()) {
    // If email was changed, force logout
    if ($email !== null && $email !== $user['email']) {
        session_destroy();
        echo json_encode(["success" => true, "message" => "Profile updated successfully. Please log in again with your new email."]);
    } else {
        echo json_encode(["success" => true, "message" => "Profile updated successfully"]);
    }
} else {
    echo json_encode(["error" => "Profile update failed"]);
}

$stmt->close();
$conn->close();
?>
