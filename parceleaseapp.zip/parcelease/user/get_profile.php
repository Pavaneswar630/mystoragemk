<?php
require '../dbconnect.php'; // Database connection

$response = array();
if ($_SERVER["REQUEST_METHOD"] == "POST") {
    $user_id = $_POST['user_id'];

    // Fetch user details
    $query = "SELECT id, name, email, profile_pic FROM users WHERE id = ?";
    $stmt = $conn->prepare($query);
    $stmt->bind_param("i", $user_id);
    $stmt->execute();
    $result = $stmt->get_result();

    if ($result->num_rows > 0) {
        $user = $result->fetch_assoc();

        // Get shipment stats
        $parcels_delivered = $conn->query("SELECT COUNT(*) AS count FROM tracking WHERE user_id = $user_id AND status = 'Delivered'")->fetch_assoc()['count'] ?? 0;
        $active_shipments = $conn->query("SELECT COUNT(*) AS count FROM parcels WHERE user_id = $user_id AND status = 'Confirmed'")->fetch_assoc()['count'] ?? 0;
        $saved_addresses = $conn->query("SELECT COUNT(*) AS count FROM saved_addresses WHERE user_id = $user_id")->fetch_assoc()['count'] ?? 0;

        // Return response
        $response['success'] = true;
        $response['user'] = array(
            "id" => $user['id'],
            "name" => $user['name'],
            "email" => $user['email'],
            "profile_image" => $user['profile_pic'], // Updated field name
            "parcels_delivered" => $parcels_delivered,
            "active_shipments" => $active_shipments,
            "saved_addresses" => $saved_addresses
        );
    } else {
        $response['success'] = false;
        $response['message'] = "User not found";
    }

    echo json_encode($response);
}

?>
