<?php
use PHPMailer\PHPMailer\PHPMailer;
use PHPMailer\PHPMailer\Exception;

require '../PHPMailer/src/PHPMailer.php';
require '../PHPMailer/src/SMTP.php';
require '../PHPMailer/src/Exception.php';

include "../dbconnect.php";

header("Content-Type: application/json");

// Check if email is provided
if (!isset($_POST['email'])) {
    echo json_encode(["status" => "error", "message" => "Email is required"]);
    exit;
}

$email = $_POST['email'];

// Check if email exists in the database
$query = "SELECT id FROM users WHERE email = ?";
$stmt = $conn->prepare($query);
$stmt->bind_param("s", $email);
$stmt->execute();
$result = $stmt->get_result();

if ($result->num_rows == 0) {
    echo json_encode(["status" => "error", "message" => "Email not found"]);
    exit;
}

$user = $result->fetch_assoc();
$user_id = $user['id'];

// Generate a unique reset token
$reset_token = bin2hex(random_bytes(16));
$token_expiry = date("Y-m-d H:i:s", strtotime("+1 hour")); // Token expires in 1 hour

// Store the reset token in the database
$update_query = "UPDATE users SET reset_token = ?, reset_expiry = ? WHERE id = ?";
$stmt = $conn->prepare($update_query);
$stmt->bind_param("ssi", $reset_token, $token_expiry, $user_id);

if (!$stmt->execute()) {
    echo json_encode(["status" => "error", "message" => "Failed to store reset token"]);
    exit;
}

// Send reset link via email
$mail = new PHPMailer(true);

try {
    // SMTP Configuration
    $mail->isSMTP();
    $mail->Host = 'smtp.gmail.com'; // Change to your SMTP server
    $mail->SMTPAuth = true;
    $mail->Username = 'pavaneswar224@gmail.com'; // Change to your email
    $mail->Password = 'azmc qwff lwxe pnvu'; // Use App Password if using Gmail
    $mail->SMTPSecure = PHPMailer::ENCRYPTION_STARTTLS;
    $mail->Port = 587;

    // Email Content
    $mail->setFrom('pavaneswar224@gmail.com', 'ParcelEase Support');
    $mail->addAddress($email);
    $mail->Subject = 'Password Reset Request';
    $mail->isHTML(true);
    $reset_link = "http://192.168.1.7/parcelease/user/resetpassword.php?token=" . $reset_token;
    $mail->Body = "Click the link below to reset your password: <br><a href='$reset_link'>$reset_link</a>";

    // Send Email
    if ($mail->send()) {
        echo json_encode(["status" => "success", "message" => "Password reset link sent to email"]);
    } else {
        echo json_encode(["status" => "error", "message" => "Failed to send email"]);
    }
} catch (Exception $e) {
    echo json_encode(["status" => "error", "message" => "Mailer Error: " . $mail->ErrorInfo]);
}

$stmt->close();
$conn->close();
?>
