<?php
include "../dbconnect.php";
header("Content-Type: application/json");

if ($_SERVER["REQUEST_METHOD"] !== "POST") {
    echo json_encode(["status" => "error", "message" => "Invalid request method"]);
    exit;
}

// Validate inputs
if (!isset($_POST['token'], $_POST['new_password'])) {
    echo json_encode(["status" => "error", "message" => "Token and new password are required"]);
    exit;
}

$token = $_POST['token'];
$new_password = $_POST['new_password'];

// Check token in the database
$query = "SELECT id, reset_expiry FROM users WHERE reset_token = ?";
$stmt = $conn->prepare($query);
$stmt->bind_param("s", $token);
$stmt->execute();
$result = $stmt->get_result();

if ($result->num_rows == 0) {
    echo json_encode(["status" => "error", "message" => "Invalid or expired token"]);
    exit;
}

$user = $result->fetch_assoc();
$user_id = $user['id'];
$token_expiry = strtotime($user['reset_expiry']);

if ($token_expiry < time()) {
    echo json_encode(["status" => "error", "message" => "Token has expired"]);
    exit;
}

// Update the password
$update_query = "UPDATE users SET password = ?, reset_token = NULL, reset_expiry = NULL WHERE id = ?";
$stmt = $conn->prepare($update_query);
$stmt->bind_param("si", $new_password, $user_id);

if ($stmt->execute()) {
    echo json_encode(["status" => "success", "message" => "Password updated successfully"]);
} else {
    echo json_encode(["status" => "error", "message" => "Failed to update password"]);
}

$stmt->close();
$conn->close();
?>
