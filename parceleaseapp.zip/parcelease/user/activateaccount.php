<?php
header('Content-Type: application/json');

$email = $_POST['email'] ?? '';

if (empty($email)) {
    echo json_encode(["status" => "error", "message" => "Email is required"]);
    exit();
}

// Assuming you have a database connection setup
require '../dbconnect.php';

// Check if user exists
$query = "UPDATE users SET status='active' WHERE email=?";
$stmt = $conn->prepare($query);
$stmt->bind_param("s", $email);
$result = $stmt->execute();

if ($result) {
    echo json_encode(["status" => "success", "message" => "Account activated successfully."]);
} else {
    echo json_encode(["status" => "error", "message" => "Failed to activate account."]);
}

$stmt->close();
$conn->close();
?>
