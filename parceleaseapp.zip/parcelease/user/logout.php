<?php
session_start(); // Start the session
session_unset(); // Unset all session variables
session_destroy(); // Destroy the session

echo json_encode(["status" => "success", "message" => "Logout successful"]);
exit;
?>
